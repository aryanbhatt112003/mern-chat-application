const express = require("express");

const router = express.Router();

const { sendMessage, getMessages, getUsers, markMessagesAsSeen } = require("../controllers/messageController");

const protect = require("../middleware/authMiddleware");

router.post("/send/:id", protect, sendMessage);
router.get("/users", protect, getUsers);
router.get("/:id", protect, getMessages);
router.put("/seen/:id", protect, markMessagesAsSeen);


module.exports = router;
