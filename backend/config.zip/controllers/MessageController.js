const Conversation =  require("../models/Conversation");
const Message = require("../models/Message");
const User = require("../models/User");
const {getIO, userSocketMap} = require("../socket");

const sendMessage = async (req, res) => {
  try {
    const {message} = req.body;

    const receiverId = req.params.id;
    const senderId = req.user.id;

    let conversation = await Conversation.findOne({
      participants:{
        $all:[senderId, receiverId],
      }
    });

    if(!conversation){
      conversation = new Conversation({
        participants:[senderId, receiverId],
      });
      await conversation.save();
    }

    const newMessage = new Message({
      senderId,
      receiverId,
      text: message,
    });

    await newMessage.save();
    conversation.messages.push(newMessage._id);
    await conversation.save();
    const receiverSocketId = userSocketMap[receiverId];
    const io = getIO();

    if (receiverSocketId) {
      io.to(receiverSocketId).emit("newMessage", newMessage);
    }
    res.status(201).json(newMessage);
    
  } catch (error) {

    console.log(error);

    res.status(500).json({
      message: "Internal Server Error"
    });

  }
};

const getMessages = async (req, res) => {
  try {
    const receiverId = req.params.id;
    const senderId = req.user.id;

    const conversation = await Conversation.findOne({
      participants:{
        $all:[senderId, receiverId],
      },
    }).populate("messages");

    if(!conversation){
      return res.status(200).json([]);
    }

    res.status(200).json(conversation.messages); 

  } catch (error) {
    console.log(error);

    res.status(500).json({
      message: "Internal Server Error",
    });
  }
};

const getUsers = async(req, res)=>{
  try{
    const loggedInUserId = req.user.id;

    const users = await User.find({
      _id:{
        $ne: loggedInUserId,
      },
    });
    res.status(200).json(users);
  }catch(error){
  console.log(error);

  res.status(500).json({
    message:"Internal Server Error",
  });
  }
};

const markMessagesAsSeen = async (req, res) => {
  try {
    const senderId = req.params.id;
    const receiverId = req.user.id;

    await Message.updateMany(
      {
        senderId,
        receiverId,
        seen: false,
      },
      {
        seen: true,
      }
    );

    const updated = await Message.find({
      senderId,
      receiverId,
    });

    console.log(updated);

    const senderSocketId = userSocketMap[senderId];

    console.log("Sender Socket:", senderSocketId);

    if (senderSocketId) {
      console.log("sendng messagesSeen event");
      getIO().to(senderSocketId).emit("messagesSeen", {
        receiverId,
      });
    }

    res.status(200).json({
      message: "Messages marked as seen",
    });
  } catch (error) {
    console.log(error);

    res.status(500).json({
      message: "Server Error",
    });
  }
};

module.exports = {
  sendMessage,
  getMessages,
  getUsers,
  markMessagesAsSeen,
};